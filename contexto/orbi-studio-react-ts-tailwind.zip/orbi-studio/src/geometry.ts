export type P = { x:number;y:number };
export type Leg = { hip:P; knee:P; ankle:P; heel:P; toe:P };
export type Face = { x:number;y:number;rotation:number;scale:number;eyeStyle:number;mouthStyle:number;eyeShiftX:number;eyeShiftY:number };
export type Design = { left:Leg;right:Leg;face:Face };
export type DragKey='left.hip'|'left.knee'|'left.ankle'|'left.heel'|'left.toe'|'right.hip'|'right.knee'|'right.ankle'|'right.heel'|'right.toe'|'face.position';
export const COLORS={ink:'#082d3b',orange:'#ff791b',cream:'#fff4dc',cyan:'#06d7e2'};
export const fresh=():Design=>({
 left:{hip:{x:114,y:238},knee:{x:106,y:270},ankle:{x:103,y:316},heel:{x:71,y:320},toe:{x:126,y:331}},
 right:{hip:{x:186,y:238},knee:{x:194,y:270},ankle:{x:197,y:316},heel:{x:171,y:331},toe:{x:229,y:320}},
 face:{x:0,y:0,rotation:0,scale:1,eyeStyle:0,mouthStyle:0,eyeShiftX:0,eyeShiftY:0}
});
export function clone<T>(v:T):T{return JSON.parse(JSON.stringify(v)) as T}
export function pathLeg(l:Leg){const cx=2*l.knee.x-(l.hip.x+l.ankle.x)/2,cy=2*l.knee.y-(l.hip.y+l.ankle.y)/2;return `M ${l.hip.x} ${l.hip.y} Q ${cx} ${cy} ${l.ankle.x} ${l.ankle.y}`}
export function pathFoot(l:Leg){
 const a=l.ankle,h=l.heel,t=l.toe;
 const dx=t.x-h.x,dy=t.y-h.y,len=Math.max(1,Math.hypot(dx,dy));
 const nx=-dy/len,ny=dx/len;
 const down=ny>0?1:-1;
 const ox=nx*down*13,oy=ny*down*13;
 // The heel-to-toe baseline and upper arch share the same outline; no detached shoe.
 return `M ${h.x} ${h.y} Q ${h.x-ox*.45} ${h.y-oy*.7} ${a.x-ox*.25} ${a.y-7} Q ${a.x+ox*.5} ${a.y-14} ${t.x} ${t.y-3} Q ${t.x+ox*.55} ${t.y+oy*.4} ${t.x+ox} ${t.y+oy} Q ${(t.x+h.x)/2+ox*1.2} ${(t.y+h.y)/2+oy*1.3} ${h.x+ox} ${h.y+oy} Q ${h.x-ox*.7} ${h.y+oy*.4} ${h.x} ${h.y} Z`;
}
export const EYES=['Clássico','Grandes','Pequenos','Pontinhos','Finos','Largos','Redondos','Esquerda','Direita','Acima','Abaixo','Felizes','Fechados','Piscada E','Piscada D','Sonolentos','Bravos','Tristes','Surpresos','Focados','Corações','Estrelas','Quadrados','Assimétricos','Com brilho','Chorosos','Desconfiados','Curiosos','Irritados','Apaixonados'];
export const MOUTHS=['Surpreso','Mini O','O grande','Sorriso','Sorriso aberto','Risada','Neutra','Triste','Triste forte','Reta','Dentes','Sério','Bico','Beijo','Assobio','Grito','Sono','Bocejo','Pensativo','Lateral E','Lateral D','Zigue-zague','Triângulo','Quadrado','Espanto','Determinado','Gargalhada','Meio sorriso','Tímido','Fechada'];
export const POSES=['Sentado neutro','Sentado relaxado','Sentado pernas abertas','Sentado pernas juntas','Sentado inclinado E','Sentado inclinado D','Sentado pernas longas','Sentado encolhido','Sentado assimétrico','Sentado descansando','Em pé neutro','Em pé aberto','Em pé fechado','Em pé inclinado E','Em pé inclinado D','Passo E','Passo D','Salto','Corrida','Ponta dos pés','Deitado direita','Deitado esquerda','Deitado relaxado','Deitado lateral','Deitado encolhido','Deitado esticado','Deitado diagonal E','Deitado diagonal D','Deitado sonolento','Deitado repousando'];
const L=(hx:number,hy:number,kx:number,ky:number,ax:number,ay:number,fx:number,fy:number,dir:number):Leg=>({hip:{x:hx,y:hy},knee:{x:kx,y:ky},ankle:{x:ax,y:ay},heel:{x:fx-31,y:fy},toe:{x:fx+dir*26,y:fy+2}});
export function pose(n:number):Design{
 const d=fresh();const g=n<10?0:n<20?1:2,sub=n%10;
 const bends=[0,-12,18,-8,-20,20,-6,27,-17,9];
 if(g===0){const y=[265,270,278,268,277,277,280,266,268,274][sub];
 d.left=L(116,236,102+bends[sub],255,86-bends[sub]*.6,y,81-bends[sub]*.5,y+8,-1);
 d.right=L(184,236,198-bends[sub],255,214+bends[sub]*.6,y,219+bends[sub]*.5,y+8,1);
 }else if(g===1){const offsets=[0,15,-15,-18,18,-27,27,3,-20,9][sub];
 d.left.knee.x+=offsets*.25;d.left.ankle.x+=offsets*.5;d.left.heel.x+=offsets*.5;d.left.toe.x+=offsets*.5;
 d.right.knee.x-=offsets*.25;d.right.ankle.x-=offsets*.5;d.right.heel.x-=offsets*.5;d.right.toe.x-=offsets*.5;
 const lift=[0,0,0,8,8,-13,0,-35,-17,-22][sub];
 for(const leg of [d.left,d.right])for(const k of ['knee','ankle','heel','toe'] as const)leg[k].y+=lift;
 }else{
 const angle=[-78,78,-90,-100,-65,88,-55,55,-110,92][sub]*Math.PI/180;
 const transform=(p:P)=>{const cx=150,cy=156,x=p.x-cx,y=p.y-cy;return{x:cx+x*Math.cos(angle)-y*Math.sin(angle),y:cy+x*Math.sin(angle)+y*Math.cos(angle)}};
 for(const leg of [d.left,d.right])for(const k of ['hip','knee','ankle','heel','toe'] as const)leg[k]=transform(leg[k]);
 }
 return d;
}
